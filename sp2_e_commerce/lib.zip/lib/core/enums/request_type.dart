enum RequestType {
  POST,
  GET,
  DELETE,
  PUT,
}
