enum TextStyleType { PX34, PX24, PX20, PX16, PX14, PX12, CUSTOM }
