enum BottomNavigationEnum {
  HOME,
  NOTIFICATIONS,
  FAVORITE,
  SETTINGS,
}
