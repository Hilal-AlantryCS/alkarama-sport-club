class FRLangauge {
 static Map<String, String> get map => {
    "key_login":"Login",

  };
}
