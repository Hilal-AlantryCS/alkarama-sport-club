enum ConnectivityStatus {
  ONLINE,
  OFFLINE,
}
