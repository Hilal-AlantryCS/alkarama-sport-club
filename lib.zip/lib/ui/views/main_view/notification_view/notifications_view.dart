import 'package:flutter/material.dart';

class NotificationsView extends StatelessWidget {
  const NotificationsView({super.key});

  @override
  Widget build(BuildContext context) {
     return Center(
      child: Text("Notifications",style: TextStyle(fontSize: 75),),
    );
  }
}